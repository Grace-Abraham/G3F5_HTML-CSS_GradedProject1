# G3F5_HTML-CSS_GradedProject1

https://drive.google.com/file/d/1aJ8z8npn_DgSclZ-Y0PvkFbaU1CCbKds/view?usp=sharing     video of working project
